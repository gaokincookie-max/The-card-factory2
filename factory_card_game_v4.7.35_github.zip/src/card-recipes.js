export const cardRecipes = {
  "infantry": [
    {
      "id": "card_1_infantry",
      "name": "歩兵分隊",
      "input": {
        "鉄鉱石": 1,
        "化学資源": 1
      },
      "seconds": 8,
      "cardType": "ユニット",
      "tags": "歩兵,人間",
      "effect": "なし"
    },
    {
      "id": "card_2_infantry",
      "name": "軽装歩兵",
      "input": {
        "鉄鉱石": 1
      },
      "seconds": 8,
      "cardType": "ユニット",
      "tags": "歩兵,人間",
      "effect": "なし"
    },
    {
      "id": "card_3_infantry",
      "name": "重装歩兵",
      "input": {
        "装甲板": 1,
        "火薬": 1
      },
      "seconds": 14,
      "cardType": "ユニット",
      "tags": "歩兵,人間,装甲",
      "effect": "なし"
    },
    {
      "id": "card_4_infantry",
      "name": "機関銃班",
      "input": {
        "鉄材": 1,
        "火薬": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "歩兵,人間,対歩兵",
      "effect": "歩兵タグを持つ対象への攻撃力+25%。"
    },
    {
      "id": "card_5_infantry",
      "name": "狙撃班",
      "input": {
        "鉄材": 1,
        "銅線": 1,
        "火薬": 1
      },
      "seconds": 14,
      "cardType": "ユニット",
      "tags": "歩兵,人間",
      "effect": "支援タグを持つ対象への攻撃力+50%。ターゲット優先順位は変えない。"
    },
    {
      "id": "card_6_infantry",
      "name": "衛生兵",
      "input": {
        "鉄材": 1,
        "薬剤": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "歩兵,人間,支援",
      "effect": "2秒ごとに隣接する生存中の味方のうち現在HPが最も低い1体を12回復（同値はランダム）。"
    },
    {
      "id": "card_7_infantry",
      "name": "野戦指揮官",
      "input": {
        "鉄材": 1,
        "銅線": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "歩兵,人間,支援",
      "effect": "隣接する味方ユニットの攻撃力+15%。自身は含まない。"
    },
    {
      "id": "card_8_infantry",
      "name": "補給班",
      "input": {
        "鉄材": 1,
        "燃料": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "歩兵,人間,支援",
      "effect": "同列の味方ユニットのリロード速度+20%。"
    },
    {
      "id": "card_9_infantry",
      "name": "火炎放射班",
      "input": {
        "鉄材": 1,
        "燃料": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "歩兵,人間,対歩兵",
      "effect": "通常攻撃の対象へ100%、その対象の左右にいる敵ユニットへ50%の攻撃力で同時攻撃。"
    },
    {
      "id": "card_10_infantry",
      "name": "突撃班",
      "input": {
        "鉄材": 1,
        "火薬": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "歩兵,人間",
      "effect": "自分の攻撃で敵前衛を撃破すると3秒間リロード速度+100%。再発動時は残り時間を3秒へ更新。"
    },
    {
      "id": "card_11_infantry",
      "name": "潜入班",
      "input": {
        "銅線": 1,
        "樹脂": 1,
        "火薬": 1
      },
      "seconds": 14,
      "cardType": "ユニット",
      "tags": "歩兵,人間,特殊",
      "effect": "同列の敵後衛を優先。後衛がいなければ前衛、双方いなければ敵本体を攻撃。"
    },
    {
      "id": "card_12_infantry",
      "name": "対戦車班",
      "input": {
        "鉄材": 1,
        "火薬": 1,
        "燃料": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "歩兵,人間,対装甲",
      "effect": "車両タグを持つ対象への攻撃力+250%。"
    },
    {
      "id": "card_13_infantry",
      "name": "対歩兵銃座",
      "input": {
        "鉄材": 1,
        "火薬": 1
      },
      "seconds": 11,
      "cardType": "ユニット",
      "tags": "兵器,機械,対歩兵",
      "effect": "歩兵タグを持つ対象への攻撃力+100%、車両タグを持つ対象への攻撃力-60%。"
    }
  ],
  "vehicle": [
    {
      "id": "card_1_vehicle",
      "name": "整備車両",
      "input": {
        "鉄材": 1,
        "電子部品": 1,
        "燃料": 1
      },
      "seconds": 14,
      "cardType": "ユニット",
      "tags": "車両,機械,支援",
      "effect": "1秒ごとに隣接する車両タグの味方全員のHPを6回復。"
    },
    {
      "id": "card_2_vehicle",
      "name": "軽戦車",
      "input": {
        "鉄材": 2,
        "装甲板": 1,
        "燃料": 1
      },
      "seconds": 14,
      "cardType": "ユニット",
      "tags": "車両,機械,装甲",
      "effect": "なし"
    },
    {
      "id": "card_3_vehicle",
      "name": "重戦車",
      "input": {
        "強化装甲": 2,
        "推進装置": 1,
        "高性能弾薬": 1
      },
      "seconds": 20,
      "cardType": "ユニット",
      "tags": "車両,機械,装甲",
      "effect": "自身の被ダメージ軽減+15%。"
    },
    {
      "id": "card_4_vehicle",
      "name": "自走砲",
      "input": {
        "精密機械": 1,
        "高性能弾薬": 1,
        "燃料": 1
      },
      "seconds": 17,
      "cardType": "ユニット",
      "tags": "車両,機械,砲兵",
      "effect": "同列の敵前衛・後衛の双方へ通常攻撃。両方不在時のみ敵本体を攻撃。"
    },
    {
      "id": "card_5_vehicle",
      "name": "防衛指揮車",
      "input": {
        "強化装甲": 1,
        "制御装置": 1
      },
      "seconds": 17,
      "cardType": "ユニット",
      "tags": "車両,機械,支援",
      "effect": "隣接する味方ユニットの被ダメージ軽減+12%。自身は含まない。"
    }
  ],
  "special": [
    {
      "id": "card_1_special",
      "name": "電子戦車両",
      "input": {
        "制御装置": 1,
        "精密機械": 1,
        "燃料": 1
      },
      "seconds": 17,
      "cardType": "ユニット",
      "tags": "車両,機械,電子,支援",
      "effect": "同列の敵前衛・後衛のうち、機械または車両タグを持つ全ユニットのリロード速度-35%。"
    },
    {
      "id": "card_2_special",
      "name": "軽度EMP",
      "input": {
        "電子部品": 1,
        "化学資源": 1
      },
      "seconds": 11,
      "cardType": "補助",
      "tags": "メタ妨害",
      "effect": "機械または車両タグを持つ敵ユニット1体の通常攻撃リロードを4秒停止。"
    }
  ],
  "support": [
    {
      "id": "card_1_support",
      "name": "資材調達",
      "input": {
        "鉄鉱石": 1
      },
      "seconds": 8,
      "cardType": "補助",
      "tags": "経済",
      "effect": "建築資材を25獲得。"
    },
    {
      "id": "card_2_support",
      "name": "緊急資材調達",
      "input": {
        "原油": 1
      },
      "seconds": 8,
      "cardType": "補助",
      "tags": "経済",
      "effect": "建築資材を18獲得し、5秒間、自動建築資材増加速度+20%。同一時限効果の再使用は時間更新のみ。"
    },
    {
      "id": "card_3_support",
      "name": "大規模調達",
      "input": {
        "鉄材": 1,
        "燃料": 1
      },
      "seconds": 11,
      "cardType": "補助",
      "tags": "経済",
      "effect": "建築資材を55獲得。"
    },
    {
      "id": "card_4_support",
      "name": "突貫工事",
      "input": {
        "銅鉱石": 1
      },
      "seconds": 8,
      "cardType": "補助",
      "tags": "経済",
      "effect": "次に建設する施設の建築資材消費-25%。建設まで持続、重複しない。"
    },
    {
      "id": "card_5_support",
      "name": "生産加速",
      "input": {
        "燃料": 1,
        "銅線": 1
      },
      "seconds": 11,
      "cardType": "補助",
      "tags": "工場支援",
      "effect": "指定した加工炉・組立加工機・カード製造工場・強化モジュールの処理速度+50%、12秒。"
    },
    {
      "id": "card_6_support",
      "name": "緊急搬送",
      "input": {
        "銅線": 1,
        "燃料": 1
      },
      "seconds": 11,
      "cardType": "補助",
      "tags": "物流",
      "effect": "自軍の全倉庫から任意のカード1枚を選び、出荷区画を無視して手札の最小番号の空きスロットへ直接移す。空きがなければ不発。"
    },
    {
      "id": "card_7_support",
      "name": "応急処置",
      "input": {
        "薬剤": 1
      },
      "seconds": 8,
      "cardType": "補助",
      "tags": "戦闘支援",
      "effect": "生存中の味方ユニット1体のHPを50回復。"
    },
    {
      "id": "card_8_support",
      "name": "集中砲撃",
      "input": {
        "鉄材": 1,
        "火薬": 1,
        "銅線": 1
      },
      "seconds": 14,
      "cardType": "補助",
      "tags": "攻撃",
      "effect": "任意の敵ユニット1体へ60確定ダメージ。"
    },
    {
      "id": "card_9_support",
      "name": "制圧射撃",
      "input": {
        "化学資源": 1
      },
      "seconds": 8,
      "cardType": "補助",
      "tags": "妨害",
      "effect": "敵ユニット1体のリロード速度-40%、5秒。"
    },
    {
      "id": "card_10_support",
      "name": "煙幕",
      "input": {
        "薬剤": 1
      },
      "seconds": 8,
      "cardType": "補助",
      "tags": "防御",
      "effect": "指定列の味方ユニットの被ダメージ軽減+30%、6秒。同一効果の再使用は時間更新のみ。"
    },
    {
      "id": "card_11_support",
      "name": "再配置命令",
      "input": {
        "銅線": 1,
        "燃料": 1
      },
      "seconds": 11,
      "cardType": "補助",
      "tags": "戦術",
      "effect": "味方ユニット1体を任意の空きスロットへ移動し、リロードを最初から開始する。"
    },
    {
      "id": "card_12_support",
      "name": "前線交代",
      "input": {
        "銅鉱石": 1
      },
      "seconds": 8,
      "cardType": "補助",
      "tags": "戦術",
      "effect": "同列の味方前衛・後衛が両方存在するとき位置交換。ユニット固有の状態を保持し、位置依存の支援は即時再判定。"
    },
    {
      "id": "card_13_support",
      "name": "対装甲ロケット",
      "input": {
        "火薬": 1,
        "燃料": 1
      },
      "seconds": 11,
      "cardType": "補助",
      "tags": "メタ攻撃",
      "effect": "任意の敵ユニット1体に、車両タグがあれば120、それ以外なら20確定ダメージ。"
    },
    {
      "id": "card_14_support",
      "name": "対歩兵爆撃",
      "input": {
        "火薬": 1,
        "原油": 1
      },
      "seconds": 11,
      "cardType": "補助",
      "tags": "メタ攻撃",
      "effect": "任意の敵ユニット1体に、歩兵タグがあれば80、それ以外なら15確定ダメージ。"
    }
  ]
};
