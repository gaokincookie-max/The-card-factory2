import {recipes,catalog,itemName,itemMods} from './engine.js';
const normalName=item=>{const raw=itemName(item);if(typeof raw==='string'&&raw.trim().startsWith('{')){try{return JSON.parse(raw).name||raw}catch{}}return raw};
const entries=Object.entries(recipes).flatMap(([kind,rs])=>rs.map(r=>({...r,kind})));
const byName=new Map(entries.map(r=>[r.name,r]));
const basicNames=new Map(Object.values(catalog).filter(b=>b.resource).map(b=>[b.resource,b.name]));
let fullData=new Map();
let unitStats=new Map();
const marks={attack:'⚔',hp:'♥',reload:'↻'};
let stack=[];
export async function registerCardData(){try{const response=await fetch('./data/card-details.json');if(response.ok){const rows=await response.json();fullData=new Map(rows.map(r=>[r['カード名'],r]));const statsResponse=await fetch('./data/unit-stats.json');if(statsResponse.ok)unitStats=new Map(Object.entries(await statsResponse.json()));}}catch(error){console.warn('Card catalog metadata unavailable:',error)}}
export function cardKind(name){const r=byName.get(name);if(r?.cardType==='ユニット')return 'unit';if(r?.cardType==='補助')return /偵察|傍受|調査/.test(name)?'recon':'support';return 'material'}
export function bindCardHold(element,action,{longPressOnly=false}={}){let timer=null,pressed=false,sx=0,sy=0,suppress=false;const clear=()=>{clearTimeout(timer);timer=null};element.addEventListener('pointerdown',e=>{if(e.button!==0)return;pressed=false;sx=e.clientX;sy=e.clientY;clear();timer=setTimeout(()=>{pressed=true;suppress=true;action();},520)});element.addEventListener('pointermove',e=>{if(Math.hypot(e.clientX-sx,e.clientY-sy)>12)clear()});for(const ev of ['pointerup','pointercancel','pointerleave'])element.addEventListener(ev,clear);element.addEventListener('click',e=>{if(suppress){e.preventDefault();e.stopImmediatePropagation();suppress=false;return}if(!longPressOnly){action();e.preventDefault()}},true);element.addEventListener('contextmenu',e=>{e.preventDefault();clear();action()})}
export function makeCard(item,{compact=false,onOpen=null}={}){const name=normalName(item)||'不明';const mods=itemMods(item);const root=document.createElement('div');root.className=`fcg-card ${cardKind(name)}${compact?' compact':''}`;root.setAttribute('role','button');root.tabIndex=0;root.setAttribute('aria-label',`${name} の詳細を開く`);const type=document.createElement('small');type.className='fcg-type';type.textContent=cardKind(name)==='unit'?'ユニット':cardKind(name)==='material'?'素材':'補助';root.append(type);const label=document.createElement('div');label.className='fcg-name';label.textContent=name;root.append(label);if(mods.length){const group=document.createElement('div');group.className='fcg-mods';for(const m of mods){const sign=document.createElement('span');sign.textContent=marks[m]||'★';sign.title={attack:'攻撃強化',hp:'耐久強化',reload:'装填強化'}[m]||m;group.append(sign)}root.append(group)}const fn=onOpen||(()=>openCardDetail(item));bindCardHold(root,fn);root.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();fn()}});return root}
const element=(tag,cls='',content='')=>{const el=document.createElement(tag);if(cls)el.className=cls;if(content)el.textContent=content;return el};
function sourceOf(name){const r=byName.get(name),data=fullData.get(name);return {r,data}}
function extractStats(item,data){
  const name=normalName(item);
  const unit=unitStats.get(name)||{};
  const mods=itemMods(item);
  // A library card is opened with its name (string), not a live unit object.
  // Preserve that name when looking up the exact battle stats record.
  const stat=item&&typeof item==='object'?item.stats||{}:{};
  const hp=stat.hp??data?.HP??unit.hp;
  const attack=stat.attack??data?.['攻撃力']??unit.attack;
  const interval=stat.interval??data?.['基本攻撃間隔']??unit.interval;
  const format=(value,suffix='')=>value==null||value===''?'—':String(value)+suffix;
  const number=value=>value==null||value===''?null:Number(value);
  const hpNum=number(hp),atkNum=number(attack),timeNum=number(interval);
  const rows=[
    ['HP',format(hp),hpNum==null?'—':format(Math.floor(hpNum*(mods.includes('hp')?1.2:1)))],
    ['攻撃力',format(attack),atkNum==null?'—':format(Math.floor(atkNum*(mods.includes('attack')?1.2:1)))],
    ['リロード時間',timeNum==null?'—':timeNum.toFixed(2)+'秒',timeNum==null?'—':(timeNum/(mods.includes('reload')?1.2:1)).toFixed(2)+'秒']
  ];
  return rows.map(([label,base,current])=>({label,base,current,improved:label==='リロード時間'?current!==base:current!==base}));
}
function render(){const overlay=document.getElementById('cardDetailOverlay'),panel=document.getElementById('cardDetailPanel');if(!overlay||!panel||!stack.length)return;const item=stack[stack.length-1],name=normalName(item),{r,data}=sourceOf(name);overlay.hidden=false;panel.replaceChildren();const header=element('div','card-detail-header');const actions=element('div','card-detail-actions');const back=element('button','','← 戻る');back.disabled=stack.length<2;back.onclick=()=>{stack.pop();render()};const exit=element('button','','× 閉じる');exit.onclick=closeCardDetail;actions.append(back,exit);header.append(element('div','card-detail-breadcrumb',`カード詳細 / ${stack.map(normalName).join(' → ')}`),actions);panel.append(header);const grid=element('div','card-detail-grid');panel.append(grid);
const left=element('section','card-detail-side');left.append(element('h3','','作り方'));grid.append(left);const factory=r?catalog[r.kind]?.name:(basicNames.get(name)||data?.['製造工場']||'製造情報なし');left.append(element('div','card-detail-muted',`使用施設：${factory}`));if(r){left.append(element('p','card-detail-muted',`製造時間：${r.seconds}秒（暫定）`));const ingredients=Object.entries(r.input||{});if(!ingredients.length)left.append(element('p','card-detail-muted','追加素材なし'));for(const [ingredient,count] of ingredients){const group=element('div','card-ingredient');group.append(makeCard(ingredient,{compact:true,onOpen:()=>openCardDetail(ingredient)}),element('b','',`×${count}`));left.append(group)}}else if(basicNames.has(name))left.append(element('p','card-detail-muted','資源ゾーン上で採集します。'));else left.append(element('p','card-detail-muted','レシピ情報は未登録です。'));
const center=element('section','card-detail-center');center.append(makeCard(item,{onOpen:()=>{}}));center.append(element('p','card-detail-art','イラスト枠は今後追加予定'));grid.append(center);
const right=element('section','card-detail-right');grid.append(right);const stats=element('div','card-detail-side');stats.append(element('h3','','基本ステータス'));for(const s of extractStats(item,data)){const line=element('div','card-detail-stat');line.append(element('span','',s.label));const val=element('span');if(String(s.base)!==String(s.current)){const base=element('del','',String(s.base));val.append(base,document.createTextNode('  '));const revised=element('b',s.improved?'positive':'negative',String(s.current));val.append(revised)}else val.textContent=String(s.base);line.append(val);stats.append(line)}if(!unitStats.has(name)&&!item?.stats&&!data?.HP)stats.append(element('p','card-detail-muted','数値未登録。戦闘データが整備されるまで「—」と表示します。'));right.append(stats);const effect=element('div','card-detail-side');effect.append(element('h3','','効果・説明'));effect.append(element('div','card-detail-effect',r?.effect||data?.['現在の効果']|| (basicNames.has(name)?'基礎原料。素材カードとして手札に届いた場合は破棄できます。':'特殊効果なし')));const mod=itemMods(item);if(mod.length)effect.append(element('p','card-detail-muted',`強化：${mod.map(x=>({attack:'攻撃力+20%',hp:'最大HP+20%',reload:'リロード速度+20%'}[x]||x)).join('、')}`));const tags=r?.tags||data?.['タグ'];if(tags)effect.append(element('p','card-detail-muted',`タグ：${tags}`));right.append(effect)}
export function openCardDetail(item){if(!item)return;stack.push(item);render()}
export function closeCardDetail(){const overlay=document.getElementById('cardDetailOverlay');if(overlay)overlay.hidden=true;stack=[]}
if(typeof document!=='undefined'){document.addEventListener('click',e=>{if(e.target?.id==='cardDetailOverlay')closeCardDetail()});document.addEventListener('keydown',e=>{if(e.key==='Escape'&&stack.length)closeCardDetail()})}
