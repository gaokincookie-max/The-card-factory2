import {FACTORY_ECONOMY} from './factory-economy-config.js';
import {WAREHOUSE_TYPES, warehouseModeLabel} from './warehouse-policy.js';
import {createTutorial} from './tutorial.js';
import {gameViewportElement,elementCenterToGame} from './viewport-coordinates.js';
import {installMobileBoardControls} from './mobile-board-controls.js';
import {mountMainMenu} from './menu.js';
import {openFacilityHelp} from './facility-guide.js';
import {createOnlineAdapter} from './online-adapter.js';
import {executeCommand} from './commands.js';
import {createBattle,loadBattleStats,advanceBattle,mountBattle} from './battle.js';
import {makeCard,openCardDetail,bindCardHold,registerCardData} from './card-ui.js';
import{SIZE,catalog,recipes,initialState,place,remove,step,beltLine,footprint,selectRecipe,buildingAt,beltAt,setWarehouseMode,useHand,setShippingGroups,warehouseStock,itemName,itemMods,inventoryCount,decodeItem}from './engine.js';
console.info('[Factory Card Game] v3.5 loaded — online live facility details');
const dispatchGame=(type,payload)=>online.active ? online.command(type,payload) : executeCommand({factory:state,battle}, {type,payload});
const commandError=(type,payload)=>{const response=dispatchGame(type,payload);return response.ok?null:(response.error||'操作に失敗しました')};
const state=initialState(),board=document.querySelector('#board'),sel=document.querySelector('#kind'),hint=document.querySelector('#hint'),log=document.querySelector('#log');let tool='inspect',beltStart=null,beltHover=null,selected=null,pending=null,category='gather';let liveFacility=null,refreshActiveFacility=null;
for(const[k,v]of Object.entries(catalog)){const o=document.createElement('option');o.value=k;o.textContent=`${v.name} (${v.cost})`;sel.append(o)}
const groups={gather:['iron','copper','oil','chem'],process:['smelter','assembler'],factory:['infantry','vehicle','special','support'],storage:['warehouseSmall','warehouseLarge'],boost:['moduleAttack','moduleHP','moduleReload']};
const battle=createBattle(state);
const online=createOnlineAdapter({state,battle,onView:()=>{refreshActiveFacility?.();updateLiveFacility();draw();if(!floatBar.hidden)positionFloat();battleUI.render();updateHud();},onStatus:msg=>note(msg),onExit:()=>{hideModal();mainMenu.open();}});
const battleUI=mountBattle(battle,document.querySelector('#battlePreview'),()=>{},dispatchGame,()=>online.active?online.team:0);loadBattleStats(battle);
function drawHand(){const root=document.getElementById('handSlots');if(!root){return;}root.replaceChildren();state.hand.forEach((item,i)=>{const slot=document.createElement('div');slot.className='hand-cell';const index=document.createElement('small');index.textContent=`SLOT ${i+1}`;slot.append(index);if(item){const card=makeCard(item,{onOpen:()=>openCardDetail(item)});slot.append(card);const discard=document.createElement('button');discard.className='hand-discard';discard.textContent='テスト破棄';discard.onclick=()=>{if(online.active){note('オンラインではテスト破棄は利用できません');return}useHand(state,i);note('手札を1枚破棄しました（テスト操作）');drawHand()};slot.append(discard)}else{const empty=document.createElement('div');empty.className='empty-hand';empty.textContent='空き';slot.append(empty)}root.append(slot)})}

function drawDock(){const dock=document.querySelector('#buildingCards');dock.replaceChildren();for(const kind of groups[category]){const v=catalog[kind];const b=document.createElement('button');b.type='button';b.className='build-card'+(tool==='build'&&sel.value===kind?' active':'');b.innerHTML=`<span class="symbol">${v.resource?'◆':kind.includes('warehouse')?'▤':'▣'}</span><span><span class="name">${v.name}</span><small>${v.size.join('×')} ・資材 ${v.cost}</small></span>`;b.onclick=()=>{sel.value=kind;tool='build';syncBeltButton();pending=null;beltStart=null;beltHover=null;showFloating(null);note(`${v.name}：場所をタップし、✓で設置してください`);drawDock();placement()};dock.append(b)}document.querySelectorAll('.tab').forEach(b=>b.classList.toggle('active',b.dataset.category===category));}
document.querySelectorAll('.tab').forEach(b=>b.onclick=()=>{category=b.dataset.category;drawDock()});document.querySelector('#dockToggle').onclick=()=>{const dock=document.querySelector('#dock');dock.classList.toggle('dock-collapsed');document.querySelector('#dockToggle').textContent=dock.classList.contains('dock-collapsed')?'⌃ メニューを開く':'⌄ メニューをしまう'};
function placement(){return; /* inline floating placement toolbar */ const el=document.querySelector('#placementInfo');if(tool!=='build'){el.textContent='建築メニューから施設を選択してください。';return;}const v=catalog[sel.value];el.textContent=`${v.name}　${v.size.join('×')}　建設費 ${v.cost}
回転：${state.rotation*90}°
${pending?`仮配置：(${pending.x}, ${pending.y})`:'配置先のマスをクリックしてください'}
※建設確定後も同じ施設を配置できます。`;}
const cells=[];for(let y=0;y<SIZE;y++)for(let x=0;x<SIZE;x++){const b=document.createElement('button');b.className='cell';b.type='button';b.title=`${x},${y}`;b.addEventListener('click',()=>click(x,y));b.addEventListener('pointerenter',()=>{if(tool==='belt'&&beltStart){beltHover={x,y};draw()}});b.addEventListener('pointerup',()=>{});board.append(b);cells.push(b)}
installMobileBoardControls({viewport:document.querySelector('.board-scroll'),board});
let lastBeltTap={key:'',time:0};board.addEventListener('click',e=>{const c=e.target.closest('.cell');if(!c||tool!=='inspect')return;const i=cells.indexOf(c),x=i%SIZE,y=Math.floor(i/SIZE),key=x+','+y,now=Date.now();if(beltAt(state,x,y)&&lastBeltTap.key===key&&now-lastBeltTap.time<330){const err=commandError('REMOVE_AT',{x,y});showFloating(null);selected=null;draw();note(err||'ベルトを撤去しました')}lastBeltTap={key,time:now};});
function note(s){if(hint)hint.textContent=s;if(log)log.textContent=`${s}\n${log.textContent}`.slice(0,600)}
const overlay=document.querySelector('#uiOverlay'),modal=document.querySelector('#modalPanel'),floatBar=document.querySelector('#floatingActions');
function hideModal(){overlay.hidden=true;liveFacility=null;modal.replaceChildren();modal.classList.remove('shipping-modal','facility-detail-modal')}overlay.addEventListener('click',e=>{if(e.target===overlay)hideModal()});
function elem(tag,cls='',text=''){const n=document.createElement(tag);if(cls)n.className=cls;if(text)n.textContent=text;return n}
function modalBase(title){modal.classList.remove('shipping-modal','facility-detail-modal');modal.replaceChildren();const bar=elem('div','modal-heading');bar.append(elem('h2','',title));const close=elem('button','', '×');close.onclick=hideModal;bar.append(close);modal.append(bar);overlay.hidden=false;return modal}
function actionButton(symbol,fn,title){const b=elem('button','float-button',symbol);b.type='button';b.title=title;b.setAttribute('aria-label',title);b.onclick=e=>{e.stopPropagation();fn()};return b}
function positionFloat(){
 if(floatBar.hidden)return;
 const point=pending&&tool==='build'?pending:selected;
 if(!point){floatBar.hidden=true;return;}
 const cell=cells[point.y*SIZE+point.x];if(!cell)return;
 // Both the anchor and this fixed bar live inside the rotated #gameViewport.
 // Convert physical screen coordinates back into its unrotated CSS axes.
 const vp=gameViewportElement();
 const p=elementCenterToGame(cell,vp);
 const barWidth=floatBar.offsetWidth||170,barHeight=floatBar.offsetHeight||55;
 const half=barWidth/2+5;
 floatBar.style.left=Math.max(half,Math.min(vp.clientWidth-half,p.x))+'px';
 // The bar translates upward by its own height in CSS. Keep it visible.
 floatBar.style.top=Math.max(barHeight+5,Math.min(vp.clientHeight-5,p.y-10))+'px';
}
function showFloating(mode){floatBar.replaceChildren();if(mode==='belt'){floatBar.append(actionButton('⤳',()=>{beltStart={...selected};beltHover={...selected};tool='belt';showFloating(null);syncBeltButton();draw();note('接続先をタップしてください')},'このベルトから接続'),actionButton('🗑',()=>{commandError('REMOVE_AT',{x:selected.x,y:selected.y});selected=null;showFloating(null);draw()},'ベルトを削除'));}if(mode==='build'){floatBar.append(actionButton('✓',()=>{if(!pending)return;const err=commandError('BUILD_FACILITY',{kind:sel.value,x:pending.x,y:pending.y,rotation:state.rotation});note(err||'建設しました');if(!err){selected=null;pending=null;tool='inspect';drawDock();syncBeltButton()}showFloating(err?'build':null);draw();updateHud()},'建築確定'),actionButton('↻',()=>{state.rotation=(state.rotation+1)%4;draw();positionFloat()},'90度回転'),actionButton('×',()=>{pending=null;tool='inspect';drawDock();syncBeltButton();draw();showFloating(null)},'配置モードを終了'));}
else if(mode==='inspect'){floatBar.hidden=true;return;}
else{floatBar.hidden=true;return}floatBar.hidden=false;positionFloat()}
function click(x,y){if(x>=11&&x<13&&y>=11&&y<13&&tool==='inspect'){selected=null;showFloating(null);openShipping();return}if(tool==='belt'){if(!beltStart){beltStart={x,y};beltHover={x,y};note(`始点 (${x},${y}) を選択。直線上の終点をタップしてください`)}else{const err=commandError('PLACE_BELT',{x1:beltStart.x,y1:beltStart.y,x2:x,y2:y});beltStart=null;beltHover=null;note(err||'ベルトを敷設しました。盤面に橙色の線が表示されます')}}else if(tool==='remove'){confirmRemove(x,y)}else if(tool==='build'){pending={x,y};showFloating('build');note('✓ 建築 / ↻ 回転 / × キャンセル')}else {const b=buildingAt(state,x,y);if(b){selected={x,y};showFloating(null);openFacility(x,y)}else if(beltAt(state,x,y)){selected={x,y};showFloating('belt')}else{selected=null;showFloating(null)}}draw();positionFloat()}
function confirmRemove(x,y){const b=buildingAt(state,x,y),belt=beltAt(state,x,y);if(!b&&!belt){note('撤去対象がありません');return}const root=modalBase('撤去の確認');const stock=b?Object.entries(b.inventory).filter(([,n])=>n>0).map(([key,n])=>[decodeItem(key).name,n]).map(([k,n])=>`${k} ×${n}`).join('、'):'';root.append(elem('p','',`${b?catalog[b.kind].name:'コンベア'}を撤去します。建築資材は返還されません。`));if(stock||b?.output||belt?.item)root.append(elem('p','warning',`注意：内部のアイテムは失われます。${stock||''}${b?.output?'／完成品あり':''}${belt?.item?'／ベルト上のアイテムあり':''}`));const row=elem('div','modal-actions');const cancel=elem('button','', 'キャンセル');cancel.onclick=hideModal;const yes=elem('button','danger','撤去する');yes.onclick=()=>{note(commandError('REMOVE_AT',{x,y})||'撤去しました');selected=null;hideModal();showFloating(null);draw()};row.append(cancel,yes);root.append(row)}
function openFacility(x,y){let b=buildingAt(state,x,y);if(!b)return;let previewRecipeId=b.recipe;const root=modalBase(catalog[b.kind].name);root.classList.add('facility-detail-modal');liveFacility={building:b};const layout=elem('div','facility-layout'),left=elem('div','facility-left'),right=elem('div','facility-right');layout.append(left,right);root.append(layout);const tabs=elem('div','facility-tabs');const content=elem('div','facility-content');left.append(tabs,content);let active=b.kind.startsWith('warehouse')?'inventory':catalog[b.kind].resource?'inventory':catalog[b.kind].module?'inventory':'recipes';function renderLeft(){tabs.replaceChildren();content.replaceChildren();for(const [key,label] of (catalog[b.kind].resource||catalog[b.kind].module||b.kind.startsWith('warehouse')?[['inventory',b.kind.startsWith('warehouse')?'在庫と排出設定':catalog[b.kind].module?'通過カード':'採集状況']]:[['recipes','レシピ選択'],['inventory','インベントリ']])){const t=elem('button',active===key?'active':'',label);t.onclick=()=>{active=key;renderLeft()};tabs.append(t)}if(active==='inventory'){const stock=b.kind.startsWith('warehouse')?warehouseStock(b).map(o=>[o.item,o.count]):Object.entries(b.inventory).filter(([,n])=>n>0).map(([key,n])=>[decodeItem(key),n]);if(!stock.length)content.append(elem('p','muted',catalog[b.kind].resource?'資源を採集して各辺のベルトから排出します':catalog[b.kind].module?'通過中のカードはベルト上に表示されます':'在庫なし')); for(const [name,count] of stock){const wrap=elem('div','inventory-card');wrap.append(makeCard(name,{compact:true,onOpen:()=>openCardDetail(name)}));wrap.append(elem('span','inventory-quantity',`×${count}`));content.append(wrap)}if(b.output){const wrap=elem('div','inventory-card');wrap.append(makeCard(b.output,{compact:true,onOpen:()=>openCardDetail(b.output)}),elem('span','inventory-quantity','完成品 ×1'));content.append(wrap)}return}const list=recipes[b.kind]||[];if(!list.length){content.append(elem('p','muted',catalog[b.kind].resource?'採集施設：資源を自動生成します。':'レシピはありません'));return}const auto=elem('button','recipe-auto-switch'+(b.mode==='auto'?' active':''),'自動生産モード');auto.onclick=()=>{commandError('SELECT_RECIPE',{buildingId:b.id,recipeId:'auto'});renderLeft();renderRight()};content.append(auto);
const gallery=elem('div','recipe-card-grid');content.append(gallery);
const sorted=[...list].sort((a,z)=>{const score=q=>q.id===b.recipe?1e6:Object.entries(q.input).reduce((n,[name,qty])=>n+Math.min(inventoryCount(b,name),qty)/qty,0)+(Object.entries(q.input).every(([name,qty])=>inventoryCount(b,name)>=qty)?100:0);return score(z)-score(a)||list.indexOf(a)-list.indexOf(z)});
for(const r of sorted){const ready=Object.entries(r.input).every(([name,n])=>inventoryCount(b,name)>=n);const wrap=elem('div','recipe-card-choice'+(previewRecipeId===r.id?' selected':'')+(b.recipe===r.id?' configured':'')+(ready?' craftable':''));wrap.dataset.recipeId=r.id;const visual=makeCard(r.name,{onOpen:()=>{}});wrap.append(visual);if(b.recipe===r.id)wrap.append(elem('small','recipe-current','設定中'));else if(ready)wrap.append(elem('small','recipe-status','製造可能'));else wrap.append(elem('small','recipe-status','素材待ち'));
// A long press opens card details. A short tap previews only, never switches production.
let longPress=false,holdTimer=null;visual.addEventListener('pointerdown',()=>{longPress=false;clearTimeout(holdTimer);holdTimer=setTimeout(()=>{longPress=true;openCardDetail(r.name)},530)});for(const event of ['pointerup','pointercancel','pointerleave'])visual.addEventListener(event,()=>clearTimeout(holdTimer));
visual.addEventListener('click',event=>{if(longPress){longPress=false;return}event.stopPropagation();previewRecipeId=r.id;renderLeft();renderRight()});
visual.addEventListener('keydown',event=>{if(event.key==='Enter'||event.key===' '){event.stopImmediatePropagation();event.preventDefault();previewRecipeId=r.id;renderLeft();renderRight()}} ,true);
gallery.append(wrap)}
}
function renderRight(){right.replaceChildren();const top=elem('div','facility-right-top');top.append(elem('strong','facility-selected-recipe','現在の生産'));const info=elem('button','info-button','ⓘ');info.onclick=()=>openFacilityHelp(b.kind);top.append(info);right.append(top);if(b.kind.startsWith('warehouse')){const stock=warehouseStock(b);right.append(elem('h3','','出荷方法'));const refreshWarehouseStock=warehouseInputs(right,b);right.append(elem('p','muted',`保管 ${stock.reduce((n,x)=>n+x.count,0)} / ${FACTORY_ECONOMY.warehouseCapacity[b.kind]}枚`));const gauge=elem('div','production-gauge');gauge.append(elem('span','','0%'));right.append(gauge);const detail=elem('div','muted','次の出荷まで');right.append(detail);const status=elem('p','state-line','出荷待機中');right.append(status);liveFacility={building:b,gauge,detail,status,warehouse:true,refreshWarehouseStock};const foot=elem('div','facility-footer');const rm=elem('button','danger','施設を撤去');rm.onclick=()=>confirmRemove(b.x,b.y);foot.append(rm);right.append(foot);return;}if(catalog[b.kind].module){const mod=catalog[b.kind].module;const label={attack:'攻撃力 +20%',hp:'最大HP +20%',reload:'リロード時間短縮（速度+20%）'}[mod];left.replaceChildren();left.append(elem('h3','','強化内容'),elem('p','',label),elem('p','muted','ユニットカードだけを強化。同種の強化は重複しません。ほかのカードはそのまま搬送します。'));const mat=elem('div','materials');right.append(mat);function renderModuleCards(){mat.replaceChildren();const item=b.moduleInput||warehouseStock(b)[0]?.item;if(item)mat.append(makeCard(item,{compact:true,onOpen:()=>openCardDetail(item)}));else mat.append(elem('p','muted','搬入待ち'));mat.append(elem('div','production-arrow','→'));const res=b.output||b.moduleResult;if(res)mat.append(makeCard(res,{compact:true,onOpen:()=>openCardDetail(res)}));else mat.append(elem('p','muted','加工後カード'));}renderModuleCards();const gauge=elem('div','production-gauge');gauge.append(elem('span','','0%'));right.append(gauge);const detail=elem('div','muted','加工待ち');right.append(detail);const status=elem('p','state-line','搬入待ち');right.append(status);liveFacility={building:b,gauge,detail,status,module:true,renderModuleCards,lastModuleKey:''};const foot=elem('div','facility-footer');const rm=elem('button','danger','施設を撤去');rm.onclick=()=>confirmRemove(b.x,b.y);foot.append(rm);right.append(foot);return;}const r=(recipes[b.kind]||[]).find(z=>z.id===(previewRecipeId||b.recipe)),inputs=r?Object.entries(r.input):[];const isPreview=!!r&&r.id!==b.recipe;const mats=elem('div','materials');if(!inputs.length)mats.append(elem('p','muted','必要素材なし'));for(const [name,n] of inputs){const tile=elem('div','material-tile');tile.append(makeCard(name,{compact:true,onOpen:()=>openCardDetail(name)}));const count=elem('span','material-number',`${inventoryCount(b,name)} / ${n}`);count.dataset.material=name;count.dataset.qty=n;tile.append(count);mats.append(tile)}right.append(mats);const stopped=!!b.output||(r&&inputs.some(([k,n])=>inventoryCount(b,k)<n));right.append(elem('div','production-arrow'+(stopped?' blocked':''),stopped?'↓  ×':'↓'));const product=r?.name||b.output&&itemName(b.output)||catalog[b.kind].resource||'未選択';const pt=elem('div','product-tile');if(product!=='未選択')pt.append(makeCard(product,{compact:true,onOpen:()=>openCardDetail(product)}));else pt.textContent=product;right.append(pt);const activeRecipe=(recipes[b.kind]||[]).find(z=>z.id===b.recipe);const total=activeRecipe?.seconds? activeRecipe.seconds*100 : catalog[b.kind].resource?300:catalog[b.kind].module?100:100;const current=catalog[b.kind].resource?b.cycle*100:b.progress||0;const pct=Math.max(0,Math.min(100,100*current/total));const gauge=elem('div','production-gauge');gauge.style.setProperty('--pct',pct+'%');gauge.append(elem('span','',`${Math.floor(pct)}%`));right.append(gauge);const detail=elem('div','muted',`完成品保持 ${b.output?'1 / 1':'0 / 1'} ／ ${pct.toFixed(0)}%`);right.append(detail);const status=elem('p','state-line',b.output?'排出口が詰まっています':stopped?'素材不足で停止中':'稼働中または待機中');right.append(status);liveFacility={building:b,gauge,detail,status,materials:mats};
if(r){const notice=elem('p','recipe-preview-note',isPreview?'プレビュー中：実際の生産は変更されていません':'現在設定中のレシピ');right.append(notice);
const confirm=elem('button','recipe-confirm',isPreview||b.mode==='auto'?'このレシピを確定する':'現在設定中');confirm.type='button';confirm.disabled=!isPreview&&b.mode==='manual';confirm.onclick=()=>{const err=commandError('SELECT_RECIPE',{buildingId:b.id,recipeId:r.id});if(err){note(err);return}previewRecipeId=r.id;if(online.active){note(r.name+' の変更命令を送信しました。サーバー反映を待機中');return}renderLeft();renderRight();note(r.name+' を生産レシピに設定しました')};top.querySelector('.facility-selected-recipe').textContent='選択中：'+r.name;top.insertBefore(confirm,info)}
const foot=elem('div','facility-footer');const removeButton=elem('button','danger','▤ 施設を撤去');removeButton.onclick=()=>confirmRemove(b.x,b.y);foot.append(removeButton);right.append(foot)}renderLeft();renderRight();const facilityId=b.id;refreshActiveFacility=()=>{if(overlay.hidden)return;const latest=state.buildings.find(x=>x.id===facilityId);if(!latest){liveFacility=null;return}const previousRecipe=b.recipe,previousMode=b.mode,previousWarehouse=b.warehouseMode,previousFilter=b.warehouseFilter;const previousInventory=JSON.stringify(b.inventory),previousOutput=JSON.stringify(b.output);b=latest;if(liveFacility)liveFacility.building=latest;const recipeChanged=previousRecipe!==b.recipe||previousMode!==b.mode;const warehouseChanged=previousWarehouse!==b.warehouseMode||previousFilter!==b.warehouseFilter;if(recipeChanged){const scroll=content.scrollTop;renderLeft();renderRight();content.scrollTop=scroll;}else if(warehouseChanged&&b.kind.startsWith('warehouse')){renderRight()}else if(previousInventory!==JSON.stringify(b.inventory)||previousOutput!==JSON.stringify(b.output)){if(b.kind.startsWith('warehouse')){liveFacility?.refreshWarehouseStock?.();}if(active==='inventory'){const scroll=content.scrollTop;renderLeft();content.scrollTop=scroll}}};}
function warehouseInputs(root,b){
  const options=elem('div','warehouse-settings');
  const title=elem('div','warehouse-current');
  const format=()=>warehouseModeLabel(b.warehouseMode,b.warehouseFilter);
  const current=elem('strong','',format());
  title.append(elem('span','','現在の出荷設定'),current);
  options.append(title);
  const select=elem('select','warehouse-mode-select');
  for(const [value,label] of [['random','すべて出荷'],['type','種類で指定'],['name','カード名で指定'],['paused','出荷停止']]){
    const item=document.createElement('option');item.value=value;item.textContent=label;select.append(item);
  }
  // A legacy tag-mode save remains operable without reintroducing the unwieldy tag picker.
  if(b.warehouseMode==='tag'){
    const legacy=document.createElement('option');legacy.value='tag';legacy.textContent='旧タグ指定（保存済み）';select.append(legacy);
  }
  select.value=b.warehouseMode;
  const selectLabel=elem('label','warehouse-setting-label','出荷方式');
  selectLabel.append(select);options.append(selectLabel);
  const filterArea=elem('div','warehouse-filter-area');options.append(filterArea);
  const stockArea=elem('div','warehouse-stock-list');options.append(stockArea);
  const apply=(mode,filter='')=>{
    if(commandError('SET_WAREHOUSE',{buildingId:b.id,mode,filter}))return false;
    current.textContent=format();return true;
  };
  function renderStock(){
    stockArea.replaceChildren();
    const stock=warehouseStock(b);
    const header=elem('div','warehouse-stock-header');
    header.append(elem('strong','','倉庫内のカード'),elem('small','',`${stock.reduce((n,x)=>n+x.count,0)}枚 / ${FACTORY_ECONOMY.warehouseCapacity[b.kind]}枚`));
    stockArea.append(header);
    if(!stock.length){stockArea.append(elem('p','muted','現在の在庫はありません'));return;}
    for(const entry of stock){
      const item=entry.item;
      const row=elem('button','warehouse-stock-item','');
      row.type='button';
      const mods=item.mods?.length?`［強化：${item.mods.join(' / ')}］`:'［無強化］';
      row.append(elem('span','',`${item.name} ${mods}`),elem('b','',`×${entry.count}`));
      if(b.warehouseMode==='name'&&b.warehouseFilter===item.name)row.classList.add('selected');
      row.onclick=()=>{
        if(apply('name',item.name)){
          select.value='name';renderFilter();renderStock();
        }
      };
      stockArea.append(row);
    }
    stockArea.append(elem('p','muted','在庫カードをタップすると、強化状態を問わず同名カードを出荷対象にできます。'));
  }
  function renderFilter(){
    filterArea.replaceChildren();
    if(b.warehouseMode==='type'){
      const type=elem('select','warehouse-type-select');
      for(const {id,label} of WAREHOUSE_TYPES){const item=document.createElement('option');item.value=id;item.textContent=label;type.append(item);}
      type.value=b.warehouseFilter||'unit';
      type.onchange=()=>{if(apply('type',type.value))renderStock();};
      const label=elem('label','warehouse-setting-label','出荷する種類');label.append(type);filterArea.append(label);
    }else if(b.warehouseMode==='name'){
      filterArea.append(elem('p','muted','下の在庫一覧から出荷するカードをタップしてください。強化違いはすべて同じカード名として扱います。'));
    }else if(b.warehouseMode==='paused'){
      filterArea.append(elem('p','muted','出荷は停止しています。在庫の搬入は継続します。'));
      const resume=elem('button','warehouse-resume','前の条件で出荷再開');
      resume.onclick=()=>{
        const mode=b.warehouseResumeMode||'random';
        const filter=b.warehouseResumeFilter||'';
        if(apply(mode,filter)){select.value=mode;renderFilter();renderStock();}
      };
      filterArea.append(resume);
    }else if(b.warehouseMode==='tag'){
      filterArea.append(elem('p','muted',`以前の設定「${b.warehouseFilter}」が有効です。新しい出荷方式へ変更できます。`));
    }
  }
  select.onchange=()=>{
    const mode=select.value;
    // Do not discard the previous card filter until the user selects a replacement.
    if(mode==='name'&&!b.warehouseFilter){
      const first=warehouseStock(b)[0]?.item.name;
      if(!first){select.value=b.warehouseMode;return;}
      if(!apply('name',first))return;
    }else if(mode==='name'){
      const first=warehouseStock(b)[0]?.item.name;
      if(!first){select.value=b.warehouseMode;return;}
      if(!apply('name',b.warehouseMode==='name'?b.warehouseFilter:first))return;
    }else if(mode==='type'){
      if(!apply('type',b.warehouseMode==='type'?b.warehouseFilter:'unit'))return;
    }else if(!apply(mode,mode==='tag'?b.warehouseFilter:''))return;
    renderFilter();renderStock();
  };
  renderFilter();renderStock();root.append(options);
  return renderStock;
}
const edges=[[0,1],[1,3],[2,3],[0,2]];function groupsFromEdges(enabled){const parent=[0,1,2,3];function find(x){while(parent[x]!==x)x=parent[x];return x}for(let i=0;i<4;i++)if(enabled[i]){const [a,b]=edges[i];parent[find(b)]=find(a)}const m=new Map();for(let i=0;i<4;i++){const k=find(i);if(!m.has(k))m.set(k,[]);m.get(k).push(i)}return [...m.values()]}
function openShipping(){const root=modalBase('出荷区画の設定');root.classList.add('shipping-modal');const scroll=elem('div','shipping-content-scroll');root.append(scroll);scroll.append(elem('p','muted','境界線をタップして、隣接マスをつなぐ／分ける。各マスは手札2枠に対応します。'));const enabled=edges.map(([a,b])=>state.shippingGroups.some(g=>g.includes(a)&&g.includes(b)));const editor=elem('div','shipping-editor');scroll.append(editor);function render(){editor.replaceChildren();const groups=groupsFromEdges(enabled);const colors=['#1c686a','#5a5791','#866443','#54734d'];for(let i=0;i<4;i++){const g=groups.findIndex(z=>z.includes(i));const tile=elem('div','ship-tile',`区画 ${g+1}`);tile.style.background=colors[g];tile.append(elem('small','',`手札 ${[[1,2],[3,4],[7,8],[5,6]][i].join('・')}`));tile.style.gridColumn=i%2===0?'1':'3';tile.style.gridRow=Math.floor(i/2)*2+1;editor.append(tile)}for(let i=0;i<4;i++){const btn=elem('button','boundary'+(enabled[i]?' joined':' separated'),enabled[i]?'つなぐ':'区切る');const pos=[['2','1'],['3','2'],['2','3'],['1','2']][i];btn.style.gridColumn=pos[0];btn.style.gridRow=pos[1];btn.onclick=()=>{enabled[i]=!enabled[i];render()};editor.append(btn)}const old=scroll.querySelector('.shipping-summary');if(old)old.remove();scroll.append(elem('p','shipping-summary',`区画数：${groups.length} ／ 容量：${groups.map(g=>g.length*2+'枚').join('・')}`))}render();const actions=elem('div','modal-actions');const cancel=elem('button','','キャンセル');cancel.onclick=hideModal;const save=elem('button','primary','この区画で決定');save.onclick=()=>{const err=commandError('SET_SHIPPING_GROUPS',{groups:groupsFromEdges(enabled)});if(err)note(err);else{hideModal();note('出荷区画を更新しました')}};actions.append(cancel,save);root.append(actions)}
function addDirectionOverlay(kind,x,y,rotation,preview){
 if(!catalog[kind])return;
 const [w,h]=footprint(kind,rotation);if(x<0||y<0||x+w>SIZE||y+h>SIZE)return;
 const el=document.createElement('div');el.className='facility-direction-overlay'+(preview?' direction-preview':'');
 const first=cells[y*SIZE+x],last=cells[(y+h-1)*SIZE+x+w-1];if(!first||!last)return;el.style.position='absolute';el.style.left=first.offsetLeft+'px';el.style.top=first.offsetTop+'px';el.style.width=(last.offsetLeft+last.offsetWidth-first.offsetLeft)+'px';el.style.height=(last.offsetTop+last.offsetHeight-first.offsetTop)+'px';
 const isMiner=!!catalog[kind].resource, warehouse=kind.startsWith('warehouse'),module=!!catalog[kind].module;
 // rotation direction = output, the reverse face is the input (except miners and warehouses)
 const dirs=['right','bottom','left','top'];const out=dirs[((rotation%4)+4)%4];const opposite=dirs[(rotation+2)%4];
 for(const side of dirs){
   let type=isMiner?'out':warehouse?(side===out?'out':'in'):(side===out?'out':side===opposite?'in':null);
   if(!type)continue;
   const marker=document.createElement('span');marker.className=`direction-marker ${side} ${type}`;
   const arrow={top:type==='out'?'↑':'↓',bottom:type==='out'?'↓':'↑',left:type==='out'?'←':'→',right:type==='out'?'→':'←'}[side];
   marker.textContent=arrow;el.append(marker);
 }
 board.append(el);
}
let directionOverlaySignature=null;
let lastDraw=0;function draw(){const bmap=new Map(),tmap=new Map(state.belts.map(b=>[`${b.x},${b.y}`,b]));for(const b of state.buildings){const[w,h]=footprint(b.kind,b.rotation);for(let y=b.y;y<b.y+h;y++)for(let x=b.x;x<b.x+w;x++)bmap.set(`${x},${y}`,b);}cells.forEach((cell,i)=>{const x=i%SIZE,y=Math.floor(i/SIZE),key=`${x},${y}`;
const cachedB=bmap.get(key),cachedT=tmap.get(key),cachedZone=state.zones.find(z=>x>=z.x&&x<z.x+2&&y>=z.y&&y<z.y+2);
const previewB=pending&&tool==='build'&&(()=>{const[w,h]=footprint(sel.value,state.rotation);return x>=pending.x&&x<pending.x+w&&y>=pending.y&&y<pending.y+h})(),previewT=beltStart&&beltHover&&(beltStart.x===beltHover.x||beltStart.y===beltHover.y)&&x>=Math.min(beltStart.x,beltHover.x)&&x<=Math.max(beltStart.x,beltHover.x)&&y>=Math.min(beltStart.y,beltHover.y)&&y<=Math.max(beltStart.y,beltHover.y);
const fingerprint=[cachedZone?.kind,cachedB?.id,cachedB?.kind,cachedB?.rotation,cachedT?.id,cachedT?.item?itemName(cachedT.item):'',(cachedT?.next||[]).join(','),(cachedT?.previous||[]).join(','),previewB?sel.value:'',previewT?'t':'',beltStart?.x===x&&beltStart?.y===y?'s':'',selected?.x===x&&selected?.y===y?'x':'',pending?.x===x&&pending?.y===y&&tool==='build'?'o':'',state.rotation].join('|');
if(cell._drawFingerprint===fingerprint)return;cell._drawFingerprint=fingerprint;
cell.className='cell';cell.textContent='';const shipping=x>=11&&x<13&&y>=11&&y<13;if(shipping){cell.classList.add('shipping');cell.textContent='⇧';}const zone=cachedZone;if(zone){cell.classList.add('zone','zone-'+(zone.kind||'iron'));cell.textContent=({iron:'鉄',copper:'銅',oil:'油',chem:'化'})[zone.kind]||'◇';cell.title=(zone.resource||'資源')+'ゾーン';}const belt=tmap.get(key);if(belt){cell.classList.add('belt');const next=state.belts.find(t=>t.id===belt.next?.[0]);const dx=next?.x-x,dy=next?.y-y;const incoming=(belt.previous||[]).length,outgoing=(belt.next||[]).length;
 const junction=incoming>1||outgoing>1;
 if(junction){
   cell.classList.add('belt-junction',outgoing>1?'junction-split':'junction-merge');
   const ins=(belt.previous||[]).map(id=>state.belts.find(q=>q.id===id)).filter(Boolean);
   const outs=(belt.next||[]).map(id=>state.belts.find(q=>q.id===id)).filter(Boolean);
   const arrows={ '1,0':'→','-1,0':'←','0,1':'↓','0,-1':'↑' };
   const edgeArrow=(q,reverse)=>arrows[[reverse?belt.x-q.x:q.x-belt.x,reverse?belt.y-q.y:q.y-belt.y].join(',')]||'•';
   const center=document.createElement('span');center.className='junction-symbol';center.textContent=outgoing>1?'分':'合';cell.append(center);
   const indicators=document.createElement('span');indicators.className='junction-ports';
   for(const source of ins){const d=document.createElement('b');d.className='junction-in';d.textContent=edgeArrow(source,true);indicators.append(d)}
   for(const target of outs){const d=document.createElement('b');d.className='junction-out';d.textContent=edgeArrow(target,false);indicators.append(d)}
   cell.append(indicators);
   if(belt.item){const dot=document.createElement('i');dot.className='junction-cargo';cell.append(dot)}
   cell.title=`${outgoing>1?'分流器':'合流器'} 入力${incoming}・出力${outgoing}`;
 }else{cell.textContent=belt.item?'●':dx===1?'→':dx===-1?'←':dy===1?'↓':dy===-1?'↑':'◆';cell.title=belt.item?itemName(belt.item):'コンベア'}}const b=bmap.get(key);if(b){cell.classList.add('occupied',b.kind);if(catalog[b.kind].module){cell.classList.add('upgrader-cell');cell.textContent={moduleAttack:'⚔',moduleHP:'♥',moduleReload:'↻'}[b.kind]||'◆'}else cell.textContent='';if(b.x===x&&b.y===y)cell.classList.add('facility-origin');cell.title=catalog[b.kind].name;}if(beltStart?.x===x&&beltStart?.y===y)cell.classList.add('belt-start');if(beltStart&&beltHover&&(beltStart.x===beltHover.x||beltStart.y===beltHover.y)){const minX=Math.min(beltStart.x,beltHover.x),maxX=Math.max(beltStart.x,beltHover.x),minY=Math.min(beltStart.y,beltHover.y),maxY=Math.max(beltStart.y,beltHover.y);if(x>=minX&&x<=maxX&&y>=minY&&y<=maxY){cell.classList.add('belt-preview');if(!belt)cell.textContent=beltStart.x===beltHover.x?(beltHover.y>beltStart.y?'↓':'↑'):(beltHover.x>beltStart.x?'→':'←')}}if(selected?.x===x&&selected?.y===y)cell.classList.add('selected');if(pending&&tool==='build'){const [w,h]=footprint(sel.value,state.rotation);if(x>=pending.x&&x<pending.x+w&&y>=pending.y&&y<pending.y+h)cell.classList.add('preview-good');if(x===pending.x&&y===pending.y){const kind=sel.value;cell.textContent='';cell.classList.add('preview-origin')}} });
  // Rebuild positioned direction labels only when buildings or placement change.
  // Previously this queried/removed/recreated every overlay during each frame.
  const directionKey=state.buildings.map(b=>`${b.id}:${b.kind}:${b.x},${b.y},${b.rotation}`).join(';')+
    (pending&&tool==='build'?`|preview:${sel.value}:${pending.x},${pending.y},${state.rotation}`:'');
  if(directionKey!==directionOverlaySignature || (state.buildings.length > 0 && !board.querySelector('.facility-direction-overlay'))){
    board.querySelectorAll('.facility-direction-overlay').forEach(el=>el.remove());
    for(const b of state.buildings)addDirectionOverlay(b.kind,b.x,b.y,b.rotation,false);
    if(pending&&tool==='build')addDirectionOverlay(sel.value,pending.x,pending.y,state.rotation,true);
    directionOverlaySignature=directionKey;
  }
  updateHud();
}
function syncBeltButton(){const b=document.querySelector('#belts');b.textContent=tool==='belt'?'↳ ベルト敷設中 · 押して終了':'↳ ベルト敷設';b.setAttribute('aria-pressed',String(tool==='belt'));b.classList.toggle('active',tool==='belt')}
document.querySelector('#belts').onclick=()=>{tool=tool==='belt'?'inspect':'belt';pending=null;beltStart=null;beltHover=null;showFloating(null);syncBeltButton();drawDock();draw();note(tool==='belt'?'始点と終点をタップしてください':'ベルトモードを終了しました')};



document.querySelector('#pauseInfo').onclick=()=>{const d=modalBase('基本操作');d.append(elem('p','','建築：下のメニューで選び、盤面をタップ→ ✓で決定、↻で回転、×で解除。施設をタップすると詳細画面が開きます。ベルトは始点と終点を選びます。出荷区画は境界線をタップして設定します。'))};
// Portrait phones use the CSS-rotated landscape layout; no orientation prompt.
window.addEventListener('keydown',e=>{if(e.key==='Escape'){hideModal();pending=null;tool='inspect';showFloating(null);drawDock();draw()}if(e.key.toLowerCase()==='r'&&pending){state.rotation=(state.rotation+1)%4;draw()}});
window.addEventListener('resize',()=>{directionOverlaySignature=null;draw();positionFloat()});document.querySelector('.board-scroll').addEventListener('scroll',positionFloat);document.querySelector('.board-scroll').addEventListener('fcg:board-viewport-change',positionFloat);
// Decouple simulation and HUD from board rendering.  A rendering exception must never stop time.
let lastSimulation=performance.now(), simulationErrors=0, renderErrors=0,lastMiniRefresh=0;
const diagnostics=document.createElement('div');diagnostics.id='runtimeDiagnostics';diagnostics.setAttribute('role','alert');diagnostics.hidden=true;
document.body.append(diagnostics);
function reportRuntime(area,error){console.error(area,error);diagnostics.hidden=false;diagnostics.textContent=`${area}: ${error?.message||error}（詳細はブラウザのコンソール）`;}
const miniRoots=[document.querySelector('#allyMini'),document.querySelector('#enemyMini')];for(const root of miniRoots){for(let row=0;row<2;row++)for(let col=0;col<5;col++){const cell=elem('span','mini-slot');cell.dataset.col=col;cell.dataset.row=row;root.append(cell)}}function updateBattleMini(){const my=online.active?(online.team??0):0;for(let side=0;side<2;side++){const team=side===0?my:1-my;const hp=battle.health[team];document.querySelector(side?'#enemyHpMini':'#allyHpMini').textContent=Math.ceil(hp);document.querySelector(side?'#enemyHpBar':'#allyHpBar').style.width=Math.max(0,100*hp/battle.maxHealth)+'%';const els=miniRoots[side].children;for(let row=0;row<2;row++)for(let col=0;col<5;col++){const u=battle.units[team][col][row],el=els[row*5+col];el.className='mini-slot'+(u?(u.hp>0?' filled':' debris'):'');el.title=u?`${u.name} / HP ${u.hp}/${u.maxHP}`:'空き';}}}function updateHud(){if(performance.now()-lastMiniRefresh>160){updateBattleMini();lastMiniRefresh=performance.now();}const t=document.querySelector('#time'),m=document.querySelector('#money');if(t)t.textContent=`経過 ${Math.floor(state.tick)}秒`;if(m)m.textContent=`建築資材 ${Math.floor(state.money)}`;}
function updateLiveFacility(){const v=liveFacility;if(!v||overlay.hidden||!v.gauge)return;const current=state.buildings.find(x=>x.id===v.building.id);if(!current)return;v.building=current;const b=current;let total=100,progress=b.progress||0,stopped=false,description='';if(v.warehouse){const signature=JSON.stringify(b.inventory);if(v.lastStockSignature!==signature){v.lastStockSignature=signature;v.refreshWarehouseStock?.();}const paused=b.warehouseMode==='paused';const delay=FACTORY_ECONOMY.warehouseDispatchSeconds[b.warehouseMode]||1;total=delay*100;progress=paused?0:Math.min(total,(b.warehouseClock||0)*100);stopped=paused||!!b.warehouseCool;description=paused?'出荷停止中（搬入は継続）':b.warehouseCool>0?`設定変更待ち ${b.warehouseCool.toFixed(1)}秒`:`次の出荷まで約 ${Math.max(0,delay-(b.warehouseClock||0)).toFixed(1)}秒`; }else if(v.module){total=100;progress=b.progress||0;stopped=!Object.values(b.inventory).some(n=>n>0)||!!b.output;description=b.output?'搬出待ち':stopped?'搬入待ち':`強化完了まで約 ${Math.max(0,(total-progress)/100).toFixed(1)}秒`;const key=JSON.stringify([b.output,b.moduleInput,b.moduleResult,Object.keys(b.inventory)]);if(v.lastModuleKey!==key){v.lastModuleKey=key;v.renderModuleCards()}}else{const r=(recipes[b.kind]||[]).find(x=>x.id===b.recipe);total=(r?.seconds||(catalog[b.kind].resource?3:1))*100;progress=catalog[b.kind].resource?(b.cycle||0)*100:(b.progress||0);const missing=r&&Object.entries(r.input).some(([name,qty])=>inventoryCount(b,name)<qty);stopped=Boolean(b.output||missing);description=b.output?'排出口が詰まっています':missing?'素材不足で停止中':`残り約 ${Math.max(0,(total-progress)/100).toFixed(1)}秒`;for(const tile of v.materials?.children||[]){const span=tile.querySelector('.material-number');if(span)span.textContent=`${inventoryCount(b,span.dataset.material)} / ${span.dataset.qty}`;}}const pct=Math.max(0,Math.min(100,100*progress/total));v.gauge.style.setProperty('--pct',pct+'%');v.gauge.firstElementChild.textContent=`${Math.floor(pct)}%`;v.detail.textContent=description;v.status.textContent=stopped?'停止中':'稼働中';v.gauge.classList.toggle('is-stopped',stopped);}
function simulationPulse(){const now=performance.now();let elapsed=Math.min(Math.max((now-lastSimulation)/1000,0),0.5);lastSimulation=now;if(window.__fcgMenuOpen)return;
  while(elapsed>0.000001){const delta=Math.min(elapsed,0.05);try{if(!online.active){step(state,delta);if(!tutorial?.battleFrozen())advanceBattle(battle,delta)}}catch(error){if(simulationErrors++<5)reportRuntime('進行処理エラー',error);break;}elapsed-=delta;}
  tutorial?.onPulse();updateHud();updateLiveFacility();
}
setInterval(simulationPulse,50);
function frame(now){requestAnimationFrame(frame);if(now-lastDraw<(battlePreviewOpen?200:350))return;lastDraw=now;
  try{if(battlePreviewOpen){battleUI.render()}else{draw();positionFloat()}}catch(error){if(renderErrors++<5)reportRuntime('描画エラー',error);}
}
let tutorial=null;
// A new CPU session must not inherit tutorial units, hand, map or scripted AI.
function beginCpuSession(){
  tutorial?.exit();
  const freshFactory=initialState();
  Object.assign(state,freshFactory);
  const existingStats=battle.stats;
  Object.assign(battle,createBattle(state));
  battle.stats=existingStats;
  battle.factory=state;
  battle.scriptedOpponents=false;
  tool='inspect'; pending=null; selected=null; beltStart=null; beltHover=null;
  hideModal(); drawDock(); draw(); battleUI.render(true); updateHud();
}
const mainMenu=mountMainMenu({openTutorial:()=>tutorial.begin(),openOnline:()=>online.show(),openBattle:()=>{beginCpuSession();if(!battlePreviewOpen)document.querySelector('#battleButton').click()},openFactory:()=>{if(battlePreviewOpen)document.querySelector('#battleButton').click()}});document.querySelector('#openMenuButton').onclick=()=>mainMenu.open();
let battlePreviewOpen=false;document.querySelector('#battleButton').onclick=()=>{battlePreviewOpen=!battlePreviewOpen;document.querySelector('#battlePreview').hidden=!battlePreviewOpen;document.querySelector('.workarea').hidden=battlePreviewOpen;document.querySelector('#dock').hidden=battlePreviewOpen;document.querySelector('#battleButton').textContent=battlePreviewOpen?'▦ 工業画面へ戻る':'⚔ 戦闘画面';if(battlePreviewOpen){battleUI.render()}};tutorial=createTutorial({factory:state,battle,openFactory:()=>{if(battlePreviewOpen)document.querySelector('#battleButton').click()},openBattle:()=>{if(!battlePreviewOpen)document.querySelector('#battleButton').click()},draw,updateDock:drawDock});drawDock();placement();note('設備を選び、工場マップで配置先をタップしてください。');draw();requestAnimationFrame(frame);


registerCardData().catch(error=>console.warn('Card details unavailable',error));

window.addEventListener('error',e=>reportRuntime('画面エラー',e.error||e.message));window.addEventListener('unhandledrejection',e=>reportRuntime('非同期エラー',e.reason));
